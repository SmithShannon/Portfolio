from model import Model
from tqdm.auto import tqdm
import numpy as np
import random
import os
import json
import subprocess
import time
import shutil
from main_game_display import play



class Controller():
    def __init__(self):
        self.number_of_models = 100 #Number of Models
        self.number_of_threads = 10 #Number of cpus
        self.iteration_number = 1
        self.epochs = 1000
        self.directory = "training/"
        self.models = []
        self.times = []
        if os.path.exists(self.directory):
            self.load_previous_models()
        else:
            os.makedirs(self.directory)

    def load_previous_models(self):
        self.iteration_number = np.max([int(i) for i in os.listdir(self.directory)])

        if os.path.exists(self.directory + str(self.iteration_number)):
            shutil.rmtree(self.directory + str(self.iteration_number) + "/")

        self.training_step_dir = self.directory + str(self.iteration_number-1) + "/"
        for model_index in range(self.number_of_models):
            model = Model(np.load(self.training_step_dir + str(model_index) + ".npy"))
            self.models.append(model)

    def initialize_training(self):
        self.training_step_dir = self.directory + str(self.iteration_number) + "/"
        os.mkdir(self.training_step_dir)
        if self.iteration_number == 1:
            for model_index in range(self.number_of_models):
                model = Model()
                model.mutate()
                model.save(self.training_step_dir + str(model_index) + ".npy")
                self.models.append(model)
        else:
            for model_index, model in enumerate(self.models):
                model.save(self.training_step_dir + str(model_index) + ".npy")

    def train_step(self):
        self.scores = []
        """This is one step for training, each of the models runs the game, then total time is used as score

        Score is then scaled by dividing my total score value.
        """

        processes = []

        f = open(self.training_step_dir + "scores.txt", "w+")

        # pbar = tqdm(total=self.number_of_models)
        # pbar.set_description("Epoch " + str(self.iteration_number))
        print("Epoch " + str(self.iteration_number))
        completed = 0
        model_index = 0
        while model_index < self.number_of_models:
            # p = subprocess.Popen(f"python main.py --save_dir {self.training_step_dir} --model_index {model_index}")
            if len(processes) < self.number_of_threads:
                p = subprocess.Popen(f"python main_game_display.py --save_dir {self.training_step_dir} --model_index {model_index}", stdout=f)
                # p = subprocess.Popen(f"python main.py --save_dir {self.training_step_dir} --model_index {model_index}", stdout=f)
                processes.append(p)
                time.sleep(0.1)
                model_index+=1

            new_completed = 0
            for poll in processes:
                if poll.poll() is None:
                    pass
                else:
                    new_completed+=1
                    processes.remove(poll)

            # pbar.update(new_completed)

        running = True
        while running:
            new_completed = 0
            running = False
            for poll in processes:
                if poll.poll() is None:
                    running = True
                else:
                    new_completed+=1
                    processes.remove(poll)

            # pbar.update(new_completed)

        model_scores = {}

        time.sleep(2)

        with open(self.training_step_dir + "scores.txt", "r") as f:
            self.scores = []
            for i in f.read().split("\n"):
                if len(list(model_scores.keys())) >= self.number_of_models:
                    break
                index = int(i.split(" - ")[0])
                value = float(i.split(" - ")[1])
                model_scores[index] = value

        self.scores = list(model_scores.values())

        self.times.append(np.max(self.scores))

        # print(self.scores)
        print(np.array(self.scores).round(2))
        print(str(np.average(self.scores)))
        print("\n")

        self.scores = np.array(self.scores)
        print(np.max(self.scores))
        self.scores = self.scores / np.sum(self.scores)

    def prepare_next_step(self):
        """Function called when models are finished training

        Randomly selects next models based on probability of total time
        Models are then mutated.
        """


        try:
            best_index = np.where(self.scores == np.max(self.scores))[0][0]
        except:
            best_index = np.random.randint(0, len(self.models)-1)
        #
        # print(best_index)
        #
        # self.models = [Model(weights=self.models[best_index].weights) for _ in range(self.number_of_models)]

        select_models = random.choices([i for i in range(len(self.models))], self.scores, k=self.number_of_models)
        self.models = []

        for model_index in select_models:
            # 10% change to put in new model
            if np.random.random() < 0.1:
                self.models.append(Model())
            else:
                self.models.append(Model(np.load(self.training_step_dir + str(model_index) + ".npy")))

        select_models = random.choices([i for i in range(len(self.models))], self.scores, k=self.number_of_models - 1)

        new_models = [Model(weights=self.models[best_index].weights)]
        for model_index in select_models:
            #10% change to put in new model
            if np.random.random() < 0.1:
                new_models.append(Model())
            else:
                new_models.append(Model(weights=self.models[model_index].weights))

        for model in self.models:
            model.mutate()

        self.iteration_number += 1

# controller = Controller()
# for _ in range(controller.epochs):
#     controller.initialize_training()
#     controller.train_step()
#     controller.prepare_next_step()
#
#     with open("all_times.json", "w+") as f:
#         json.dump([int(i) for i in controller.times], f)
#     f.close()

f = open("all_scores.txt", "w+")

for model in tqdm(range(1, len(os.listdir("training_final/"))+1)):
    p = subprocess.Popen(f"python main_game_display.py --save_dir training_final/{model}/ --model_index 0",
                         stdout=f)

    while True:
        if p.poll() is None:
            pass
        else:
            break