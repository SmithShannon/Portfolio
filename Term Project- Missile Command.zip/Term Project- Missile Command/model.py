import pandas as pd
import numpy as np
import math

def randomize(x):
    r = np.random.random()
    if r <= 0.1:
        return x + np.random.uniform(-0.1, 0.1)
    return x

def trim(x):
    if x >= 1:
        return 1
    elif x<= -1:
        return -1
    return x

class Model():
    def __init__(self, weights=None):
        """When class is created, it is either created with previos weights, or randomly initiated

        -Input size is 49 (of data points)
        -Output size is 3 (shoot, x and y)
        -Model has a 10% chance to mutate each weight
        """
        self.input_size = 5
        self.output_size = 3

        if weights is None:
            self.weights = np.random.uniform(-1, 1, (self.output_size, self.input_size))
        else:
            self.weights = weights

    def feed_forward(self, inputs):
        return [trim(i) for i in (inputs * self.weights).sum(axis=1)]

    def mutate(self):
        """When mutating, there is a 10% chance per weight to reinitialize (randomize) its value.
        """

        self.weights = np.array([[randomize(i) for i in array] for array in self.weights])

    def save(self, file_name):
        np.save(file_name, self.weights)